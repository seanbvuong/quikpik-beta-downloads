//#region src/shared/picStorage.ts
var e = "saved-pics", t = "quikpik-saved-pics";
function n(e) {
	return e.trim().toLocaleLowerCase();
}
function r(e) {
	return {
		...e,
		keyword: n(e.keyword)
	};
}
function i(e) {
	return new Promise((t, n) => {
		e.addEventListener("success", () => t(e.result)), e.addEventListener("error", () => n(e.error ?? /* @__PURE__ */ Error("IndexedDB request failed.")));
	});
}
function a(e) {
	return new Promise((t, n) => {
		e.addEventListener("complete", () => t()), e.addEventListener("abort", () => n(e.error ?? /* @__PURE__ */ Error("IndexedDB transaction aborted."))), e.addEventListener("error", () => n(e.error ?? /* @__PURE__ */ Error("IndexedDB transaction failed.")));
	});
}
function o() {
	return new Promise((t, n) => {
		let r = indexedDB.open("quikpik-options", 1);
		r.addEventListener("upgradeneeded", () => {
			let t = r.result;
			t.objectStoreNames.contains(e) || t.createObjectStore(e, { keyPath: "id" });
		}), r.addEventListener("success", () => t(r.result)), r.addEventListener("error", () => n(r.error ?? /* @__PURE__ */ Error("Could not open IndexedDB.")));
	});
}
function s() {
	try {
		let e = localStorage.getItem(t);
		if (!e) return [];
		let n = JSON.parse(e);
		return Array.isArray(n) ? n.filter((e) => typeof e?.id == "string" && typeof e.keyword == "string" && typeof e.name == "string" && typeof e.url == "string" && e.url.startsWith("data:")) : [];
	} catch {
		return [];
	}
}
async function c(e) {
	return (await fetch(e)).blob();
}
async function l(r) {
	let i = s();
	if (i.length === 0) return [];
	let o = Date.now(), l = await Promise.all(i.map(async (e, t) => ({
		blob: await c(e.url),
		createdAt: o - t,
		id: e.id,
		keyword: n(e.keyword),
		name: e.name,
		sortOrder: t
	}))), u = r.transaction(e, "readwrite"), d = u.objectStore(e);
	return l.forEach((e) => d.put(e)), await a(u), localStorage.removeItem(t), l;
}
function u(e) {
	return [...e].sort((e, t) => {
		let n = Number.isFinite(e.sortOrder), r = Number.isFinite(t.sortOrder);
		return n && r ? e.sortOrder - t.sortOrder || t.createdAt - e.createdAt : n ? -1 : r ? 1 : t.createdAt - e.createdAt;
	});
}
function d(e) {
	return e.map((e, t) => ({
		...e,
		sortOrder: t
	}));
}
async function f(t) {
	let n = await o(), s = await i(n.transaction(e, "readonly").objectStore(e).getAll());
	if (s.length === 0) s = await l(n);
	else {
		let t = s.map(r), i = t.some((e, t) => e.keyword !== s[t].keyword), o = t.some((e) => !Number.isFinite(e.sortOrder)), c = o ? d(u(t)) : u(t);
		if (i || o) {
			let t = n.transaction(e, "readwrite"), r = t.objectStore(e);
			c.forEach((e) => r.put(e)), await a(t);
		}
		s = c;
	}
	return s = u(s), typeof t == "number" && s.length > t && (s = s.slice(0, t)), n.close(), s;
}
//#endregion
//#region src/shared/keywordMatching.ts
function p(e, t) {
	let r = n(e);
	return r ? [...new Set([...t].map(n))].filter((e) => e && (r === e || r.endsWith(` ${e}`))).sort((e, t) => t.length - e.length)[0] ?? "" : "";
}
var m = {
	customSites: [],
	enabledGlobally: !0,
	pasteKeywordBehavior: "keep"
};
function h(e) {
	let t = String(e || "").trim().toLocaleLowerCase();
	if (!t) return "";
	try {
		return new URL(t.includes("://") ? t : `https://${t}`).hostname.replace(/^www\./, "");
	} catch {
		return t.replace(/^https?:\/\//, "").split(/[/?#]/)[0].replace(/^www\./, "").trim();
	}
}
function g(e) {
	return e === "localhost" || /^(?:\d{1,3}\.){3}\d{1,3}$/.test(e) ? !0 : /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/.test(e);
}
function _(e, t = "") {
	return String(e || "").trim().replace(/\s+/g, " ") || t;
}
function v(e) {
	if (!Array.isArray(e)) return [];
	let t = /* @__PURE__ */ new Set();
	return e.reduce((e, n) => {
		let r = n && typeof n == "object" ? n : {}, i = h(String(r.hostname || ""));
		if (!i || !g(i) || t.has(i)) return e;
		let a = _(String(r.name || ""), i);
		return t.add(i), [...e, {
			enabled: r.enabled !== !1,
			hostname: i,
			name: a
		}];
	}, []);
}
function y(e) {
	let t = e && typeof e == "object" ? e : {};
	return {
		customSites: v(t.customSites),
		enabledGlobally: t.enabledGlobally !== !1,
		pasteKeywordBehavior: t.pasteKeywordBehavior === "delete" ? "delete" : "keep"
	};
}
//#endregion
//#region src/shared/sitePermissions.ts
var b = "quikpik-site-";
function x(e) {
	let t = h(e);
	return t ? t === "localhost" || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(t) ? [`*://${t}/*`] : [`*://*.${t}/*`] : [];
}
function S(e) {
	let t = h(e);
	return `${b}${Array.from(t, (e) => e.codePointAt(0)?.toString(36) ?? "0").join("-")}`;
}
function C(e) {
	return e.startsWith(b);
}
//#endregion
//#region src/shared/runtimeMessages.ts
function w(e) {
	if (!e || typeof e != "object" || !("type" in e)) return !1;
	let t = e;
	return t.type === "quikpik:get-keyword-pics" ? typeof t.keyword == "string" : t.type === "quikpik:open-options-page";
}
chrome.action.onClicked.addListener(() => {
	chrome.runtime.openOptionsPage().catch((e) => {
		console.error("quikpik: failed to open options page from toolbar", e);
	});
}), chrome.runtime.onInstalled.addListener(() => {
	D();
}), chrome.runtime.onStartup.addListener(() => {
	D();
}), chrome.storage.onChanged.addListener((e, t) => {
	t === "local" && e["quikpik-settings"] && D();
}), chrome.runtime.onMessage.addListener((e, t, n) => !T(t) || !w(e) ? !1 : e?.type === "quikpik:open-options-page" ? (chrome.runtime.openOptionsPage().then(() => n({ ok: !0 })).catch((e) => {
	console.error("quikpik: failed to open options page", e), n({
		ok: !1,
		error: e instanceof Error ? e.message : "Could not open options page."
	});
}), !0) : e?.type === "quikpik:get-keyword-pics" ? (O(e.keyword).then((e) => n({
	ok: !0,
	keyword: e.keyword,
	pics: e.pics
})).catch((e) => {
	console.error("quikpik: failed to load popup pics", e), n({
		ok: !1,
		error: e instanceof Error ? e.message : "Could not load popup pics."
	});
}), !0) : !1);
function T(e) {
	return e?.id === chrome.runtime.id && e.tab?.id !== void 0;
}
async function E() {
	return y((await chrome.storage.local.get("quikpik-settings"))["quikpik-settings"] ?? m);
}
async function D() {
	let e = await E(), t = (await chrome.scripting.getRegisteredContentScripts()).map((e) => e.id).filter(C);
	if (t.length > 0 && await chrome.scripting.unregisterContentScripts({ ids: t }), !e.enabledGlobally) return;
	let n = (await Promise.all(e.customSites.filter((e) => e.enabled).map(async (e) => {
		let t = x(e.hostname);
		return t.length > 0 && await chrome.permissions.contains({ origins: t }) ? {
			allFrames: !1,
			css: ["content.css"],
			id: S(e.hostname),
			js: ["content.js"],
			matches: t,
			persistAcrossSessions: !0,
			runAt: "document_idle"
		} : null;
	}))).filter((e) => e !== null);
	n.length > 0 && await chrome.scripting.registerContentScripts(n);
}
async function O(e) {
	let t = n(String(e || ""));
	if (!t) return {
		keyword: "",
		pics: []
	};
	let r = await f(50), i = p(t, r.map((e) => e.keyword));
	if (!i) return {
		keyword: "",
		pics: []
	};
	let a = r.filter((e) => e.keyword === i);
	return {
		keyword: i,
		pics: await Promise.all(a.map(async (e) => ({
			createdAt: e.createdAt,
			id: e.id,
			keyword: e.keyword,
			name: e.name,
			url: await k(e.blob)
		})))
	};
}
async function k(e) {
	let t = await e.arrayBuffer(), n = new Uint8Array(t), r = 32768, i = [];
	for (let e = 0; e < n.length; e += r) i.push(String.fromCharCode(...n.subarray(e, e + r)));
	return `data:${e.type || "image/png"};base64,${btoa(i.join(""))}`;
}
//#endregion
export { D as syncSiteContentScripts };
